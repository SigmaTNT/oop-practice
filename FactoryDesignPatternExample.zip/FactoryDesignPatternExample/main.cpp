#include <iostream>
using namespace std;

class Shape
{
public:
   virtual void area()=0;
   static Shape* createObject(int);
};



class Triangle: public Shape{
public:
    void area()
    {
        cout<<"Area of triangle"<<endl;
    }
};

class Rectangle: public Shape{
public:
    void area()
    {
        cout<<"Area of rectangle"<<endl;
    }
};

class Square: public Shape{
public:
    void area()
    {
        cout<<"Area of square"<<endl;
    }
};

Shape* Shape::createObject(int i)
{
    if(i==1)
    {
        return new Triangle();
    }
    else if(i==2)
    {
        return new Rectangle();
    }
    else if(i==3)
    {
        return new Square();
    }
    else
    {
        return NULL;
    }
}

int main()
{
    Shape *p = Shape::createObject(3);
    p->area();

    return 0;
}
