#include <iostream>
using namespace std;

float divide(int a, int b)
{
    if(b==0)
         throw 0;
    return (float)a/b;
}

int main()
{
    int n1, n2;
    cout<<"Enter the first value : ";
    cin>>n1;
    cout<<"Enter the second value : ";
    cin>>n2;

    float result=-1;
    try{
        result = divide(n1, n2);
    }
    catch(int n)
    {
        cerr<<"Error"<<endl;
    }
    cout<<result<<endl;

    cout<<"asdasdasdadhja";

    return 0;
}
