#include <iostream>
using namespace std;

class Rational{
private:
	int p, q;
public:
	Rational(){}
	Rational(int a, int b){
		p = a;
		q = b;
	}
	void display()
	{
		cout << p << "/" << q << endl;
	}
	Rational operator+(Rational &r)
	{
		Rational result;
		result.setP(p*r.q + r.p*q);
		result.setQ(q*r.q);

		return result;
	}

	void setP(int p)
	{
		this->p = p;
	}
	void setQ(int q)
	{
		this->q = q;
	}
};

int main()
{
	Rational r1(2,5);
	Rational r2(3,6);
	r1.display();
	r2.display();

	Rational r3;
	r3 = r1 + r2;
	r3.display();

	/*int a;
	int b;
	a = 10;
	b = 12;
	int c;
	c = a+b;
	cout << c << endl;
	*/
	return 0;
}