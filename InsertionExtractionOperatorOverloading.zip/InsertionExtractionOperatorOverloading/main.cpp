#include "Time.h"

istream& operator>>(istream& i, Time& t1)
{
    cout<<"enter hours : ";
    i>>t1.h;
    cout<<"enter minutes : ";
    i>>t1.m;
    cout<<"enter seconds : ";
    i>>t1.s;

    return i;
}

ostream& operator<<(ostream& o, Time& t1)
{
    o<<t1.h<<endl;
    o<<t1.m<<endl;
    o<<t1.s<<endl;
    return o;
}

int main()
{
    //

    /*
    int n;
    cin>>n;
    cout<<n;
    */

    Time t;
    cin>>t;
    cout<<t;

    return 0;
}
