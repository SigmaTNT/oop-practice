#include "Time.h"

Time::Time()
{
    h=m=s=0;
}
Time::Time(int h,int m,int s)
{
    setMin(m);
    setHour(h);
    setSecond(s);
}
Time::Time(const Time& t)
{
    setMin(t.m);
    setHour(t.h);
    setSecond(t.s);
}
void Time::setHour(int h)
{
    if(h>=0 && h<=23)
    {
        this->h=h;
    }
    else
    {
        cerr<<"Invalid value of hour"<<endl;
    }
}
void Time::setMin(int m)
{
    if(m>=0 && m<=59)
    {
        this->m=m;
    }
    else
    {
        cerr<<"Invalid value of minute"<<endl;
    }
}
void Time::setSecond(int s)
{
    if(s>=0 && s<=59)
    {
        this->s=s;
    }
    else
    {
        cerr<<"Invalid value of second"<<endl;
    }
}
int Time::getHour()
{
    return h;
}
int Time::getMin()
{
    return m;
}
int Time::getSecond()
{
    return s;
}

void display(Time t1)
{
    cout<<t1.h<<endl;
    cout<<t1.m<<endl;
    cout<<t1.s<<endl;
}
