#pragma once
#include <iostream>
using namespace std;

class Time
{
private:
    int h;
    int m;
    int s;
public:
    Time();
    Time(int,int,int);
    Time(const Time&);
    void setHour(int);
    void setMin(int);
    void setSecond(int);
    int getHour();
    int getMin();
    int getSecond();
    friend void display(Time t1);
    friend istream& operator>>(istream& i, Time& t1);
    friend ostream& operator<<(ostream& o, Time& t1);
};



