#include<iostream>


using namespace std;



class Engine
{
	int chasis;

public:
	Engine()
	{
		chasis = 0;
	}
	Engine(int a) :chasis(a) {}

	Engine(const Engine& t)
	{
		chasis = t.chasis;
	}
	void display()
	{
		cout << "Chasis number = " << chasis << endl;
	}
};

class Break
{
	int discsize;
public:
	Break()
	{
		discsize = 0;
	}
	
	Break(int a) :discsize(a) {}

	Break(const Break& t)
	{
		discsize = t.discsize;

	}

	void display()
	{
		cout << "Discsize = " << discsize << endl;

	}
};


class Gear
{
	int number;
public:
	Gear()
	{
		number = 0;
	}

	Gear(int a) :number(a) {}

	Gear(const Gear& t)
	{
		number= t.number;

	}

	void display()
	{
		cout << " Number of gears = " << number << endl;

	}

};


class Car
{
	Engine obj1;
	Gear obj2;
	Break obj3;
	int model;

public:
	Car()
	{
		model = 0;
	}
	Car(int m) :model(m) {}


	Car(const Car& t)
	{
		model = t.model;
	}


	void display()
	{
		
		Engine obj1(20561);
		
		Gear obj2(7);

		Break obj3(13);
		cout << "Model of the car = " << model << endl;

		obj1.display();
		obj2.display();
		obj3.display();




	}

};

int main()
{
	int model;
	cout << "Please enter the model of the car\n";
	cin >> model;
	Car obj(model);
	obj.display();

	system("pause");
	return 0;

}