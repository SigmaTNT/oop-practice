#include<iostream>
using namespace std;

class Date
{
private:
	int day;
	int month;
	int year;

public:

	Date()
	{
		day = month = year = 0;
	}

	Date(int &a, int &b, int &c) :day(a), month(b), year(c)
	{};

	Date(const Date& t)
	{
		day = t.day;
		month = t.month;
		year = t.year;

	}

	void setday(int &a)
	{
		day = a;
	}
	void setmonth(int &a)
	{
		month = a;
	}
	void setyear(int &a)
	{
		year = a;
	}

	int& getday()
	{
		return day;
	}

	int& getmonth()
	{
		return month;
	}
	int& getyear()
	{
		return year;
	}

	void operator =(Date obj)
	{
		day = obj.day;
		month = obj.month;
		year = obj.year;
	}

	void display()
	{

		cout << "Date = " << day << "/" << month << "/" << year << endl;

	}


	~Date() { cout << "Date Destructor\n"; }

};
class Student
{

private:
	char* name;
	char* reg_no;
	float cgpa;
	Date dob;

public:
	Student()
	{

		name = nullptr;
		reg_no = nullptr;
		cgpa = 0.0;

	}
	Student(char* n, char* reg, float c) :name(n), reg_no(reg), cgpa(c)
	{}

	Student(const Student& t)
	{
		name = t.name;
		reg_no = t.reg_no;
		cgpa = t.cgpa;
	}

	void setname(char* a)
	{
		name = a;
	}

	void setreg(char* a)
	{
		reg_no = a;
	}

	void setcgpa(float a)
	{
		cgpa = a;
	}

	char* getname()
	{
		return name;
	}

	char* getreg()
	{
		return reg_no;
	}

	float getcgpa()
	{
		return cgpa;
	}


	void printstudent(int d,int m,int y)
	{
		cout << "Name = " << name << endl;
		cout << "Registration number = " << reg_no << endl;
		cout << "CGPA of " << name << " " << cgpa << endl;
		dob.setday(d);
		dob.setmonth(m);
		dob.setyear(y);
		dob.display();
	}

	void operator =(Student obj)
	{
		name = obj.name;
		reg_no = obj.reg_no;
		cgpa = obj.cgpa;

	}


	~Student()
	{
		delete[] name;
		delete[] reg_no;
		cout << "Destructor\n";

	}

};


int main()
{
	char* name = new char[15];

	char* reg_no = new char[13];

	float cgpa = 0.0f;

	cout << " Enter name :";

	cin.getline(name, 15);

	cout << " Enter Registration number : ";

	cin >> reg_no;

	cout << " Enter cgpa : ";

	cin >> cgpa;
	int day;
	int month;
	int year;

	
	
	cout << " Enter Date : ";
	cin >> day;
	cin >> month;
	cin>> year;
	/*Date dob;
	cout << "Getters\n";
	cout << dob.getday() << endl;
	cout << dob.getmonth() << endl;
	cout << dob.getyear() << endl << endl;*/

	Student obj(name, reg_no, cgpa);

	obj.printstudent(day,month,year);

	
	
	return 0;
}
