
#include<iostream>

using namespace std;

class Milk
{
private:
	int quant;
public:
	Milk()
	{
		quant = 0;
	}
	Milk(int a)
	{
		cout << "Quant = " << a<<endl;
	}


};
class Tea
{
private:
	int quant;
public:
	Tea() {};
	Tea(int a)
	{
		cout << "Quant = " << a << endl;
	}


};



class Water
{
private:
	int quant;
public:
	Water() {};
	Water(int a)
	{
		cout << "Quant = " << a << endl;
	}


};


class Sugar
{
private:
	int quant;
public:
	Sugar() {};
	Sugar(int a)
	{
		cout << "Quant = " << a << endl;
	}


};

class Cup 
{
private:
	Milk m;
	Sugar s;
	Water w;
	Tea t;

public:
	Cup()
	{
		cout << "Constructor\n";
	}

	void display()
	{
		Milk m(2);
		Sugar s(3);
		Water w(4);
		Tea t(1);

	}
};


int main()
{
	Cup obj;
	
	obj.display();

	system("pause");
	
	return 0;

}