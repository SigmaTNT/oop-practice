#include<iostream>

using namespace std;

class Teacher
{
	int pay;
public:
	Teacher()
	{
		pay=0;
	}
	Teacher(int a) :pay(a)
	{
	}

	void display()
	{
		cout << "Pay of teacher = " << pay << endl;
	}

};

class Student
{
	int fee;
public:
	Student()
	{
		fee =0;
	}
	Student(int a) : fee(a)
	{

	}

	void display()
	{
		cout << "Name of Student = " << fee << endl;
	}

};

class Marker
{
	int serialnum;
public:
	Marker()
	{
		serialnum = 0;
	}
	Marker(int a):serialnum(a){}

	void display()
	{
		cout << "Serial Number of the marker = " << serialnum << endl;
	}

};


class Board
{
	int size;
public:
	Board()
	{
		size = 0;
	}
	Board(int a) :size(a) {};

	void display()
	{
		cout << "Board size = " << size << endl;
	}
};




class Classroom
{
private:
	int num;
	Marker obj1;
	Board obj2;
public:
	Classroom()
	{

		num = 0;

	}
	Classroom(int a)
	{
		
		num = a;

	}

	void display()
	{

		cout << "Room number = " << num << endl;
		Marker obj1(5);
		obj1.display();
		
		Board obj2(10);
		obj2.display();
	}



};




class University
{
private:
	char* name;
	Classroom obj1;
	Teacher obj2;
	Student obj3;

public:
	University()
	{
		name = nullptr;
		
	}
	University(char* na) :name(na) {}

	void display()
	{
		cout << "University name = " <<name << endl;
	
		Classroom obj1(401);
		obj1.display();

		Teacher obj2(90000);
		obj2.display();

		Student obj3(10000);
		obj3.display();
	}

};



int main()
{
	char* name=new char[4];
	cin.getline(name, 4);
	University obj(name);
	obj.display();

	system("pause");
	return 0;

}