#include<iostream>

using namespace std;

class Ram
{
	int model;
	int make;
	float frequency;
public:
	Ram()
	{
		model = make =0;
		frequency = 0.0f;
	}

	Ram(int a, int b,float c) :model(a), make(b),frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}
	~Ram() {};

};

class Hdd
{
	int model;
	int make;
	float frequency;
public:
	Hdd()
	{
		model = make = 0;
		frequency = 0.0f;
	}

	Hdd(int a, int b, float c) :model(a), make(b), frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}


	~Hdd() {};


};

class Gpu
{
	int model;
	int make;
	float frequency;
public:
	Gpu()
	{
		model = make = 0;
		frequency = 0.0f;

	}

	Gpu(int a, int b, float c) :model(a), make(b), frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}

	~Gpu() {};

};



class Cpu
{
	int model;
	int make;
	float frequency;
public:
	Cpu()
	{
		model = make = 0;
		frequency = 0.0f;

	}

	Cpu(int a, int b, float c) :model(a), make(b), frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}

	~Cpu() {};

};

class Motherboard
{
	int model;
	int make;
	float frequency;
public:
	Motherboard()
	{
		model = make = 0;
		frequency = 0.0f;
	}

	Motherboard(int a, int b, float c) :model(a), make(b), frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}

	~Motherboard() {};
};

class Sound
{
	int model;
	int make;
	float frequency;
public:
	Sound()
	{
		model = make = 0;
		frequency = 0.0f;
	}

	Sound(int a, int b, float c) :model(a), make(b), frequency(c)
	{
	}
	void displayobj()
	{
		cout << "Model = " << model << endl;
		cout << "Make = " << make << endl;
		cout << "Frequency = " << frequency << endl;

	}

	~Sound() {};

};


class Computer
{
private:
	Ram obj1;
	Cpu obj2; Hdd obj3; Gpu obj4; Motherboard obj5;  Sound obj6;

public:

	Computer()
	{
		cout << "Default\n";
	}


	void display()
	{
		cout << "Following are the components of this computer\n";

		Ram obj1(20, 40, 50);
		Cpu obj2(100, 200, 300);
		Hdd obj3(25, 26, 27);
		Gpu obj4(5, 6, 7);
		Motherboard obj5(11, 23, 100);
		Sound obj6(100, 230, 700);

		cout << "Ram details are \n";
		obj1.displayobj();

		cout << "Cpu details are \n";
		obj2.displayobj();

		cout << "Hdd details are \n";
		obj3.displayobj();

		cout << "Gpu details are \n";
		obj4.displayobj();

		cout << "Motherboard details are \n";
		obj5.displayobj();

		cout << "Sound details are \n";
		obj6.displayobj();

		cout << "End\n";

	}


};
int main()
{
	Computer obj;

	obj.display();
	system("pause");
	return 0;

}